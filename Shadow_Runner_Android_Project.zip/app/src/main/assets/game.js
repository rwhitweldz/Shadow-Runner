(() => {
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const $=id=>document.getElementById(id);
let W=0,H=0,dpr=1,state='home',last=0,elapsed=0,spawn=0,objects=[],particles=[],lane=1,targetLane=1,jump=0,score=0,runCoins=0,speed=1,shield=false,toastTimer=0;
let save=loadSave();
function loadSave(){try{return Object.assign({bank:0,best:0,magnet:0,shield:0,boost:0},JSON.parse(localStorage.getItem('sr-save')||'{}'))}catch(e){return {bank:0,best:0,magnet:0,shield:0,boost:0}}}
function persist(){localStorage.setItem('sr-save',JSON.stringify(save));updateHome()}
function updateHome(){$('best').textContent=save.best;$('bank').textContent=save.bank;$('shopBank').textContent=save.bank}
function resize(){dpr=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener('resize',resize);resize();
function show(id){['home','shop','gameover','pause'].forEach(x=>$(x).classList.toggle('hidden',x!==id));$('hud').classList.toggle('hidden',id!=='playing')}
function toast(t){$('toast').textContent=t;$('toast').style.opacity=1;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').style.opacity=0,900)}
function start(){state='playing';show('playing');elapsed=0;spawn=.7;objects=[];particles=[];lane=1;targetLane=1;jump=0;score=0;runCoins=0;speed=1;shield=save.shield>0;if(shield){save.shield--;persist()}$('runCoins').textContent='0';last=performance.now();requestAnimationFrame(loop)}
function end(){state='gameover';save.bank+=runCoins;save.best=Math.max(save.best,Math.floor(score));persist();$('finalScore').textContent=Math.floor(score);$('earned').textContent=runCoins;show('gameover')}
function pause(){if(state==='playing'){state='paused';show('pause')}}
function resume(){if(state==='paused'){state='playing';last=performance.now();show('playing');requestAnimationFrame(loop)}}
window.showPauseFromAndroid=pause;
$('playBtn').onclick=start;$('againBtn').onclick=start;$('homeBtn').onclick=()=>{state='home';show('home')};$('pauseBtn').onclick=pause;$('resumeBtn').onclick=resume;$('quitBtn').onclick=end;
$('shopBtn').onclick=()=>{updateHome();show('shop')};$('shopBack').onclick=()=>show('home');
function buy(key,cost,label){if(save[key]){toast('ALREADY OWNED');return}if(save.bank<cost){toast('NOT ENOUGH ENERGY');return}save.bank-=cost;save[key]=1;persist();toast(label+' UNLOCKED')}
$('magnetBuy').onclick=()=>buy('magnet',30,'MAGNET CORE');$('shieldBuy').onclick=()=>buy('shield',50,'SHIELD CHARGE');$('boostBuy').onclick=()=>buy('boost',40,'ENERGY BOOST');
let startX=0,startY=0;
canvas.addEventListener('touchstart',e=>{let t=e.changedTouches[0];startX=t.clientX;startY=t.clientY},{passive:true});
canvas.addEventListener('touchend',e=>{if(state!=='playing')return;let t=e.changedTouches[0],dx=t.clientX-startX,dy=t.clientY-startY;if(Math.abs(dx)>Math.abs(dy)){if(dx>25)targetLane=Math.min(2,targetLane+1);else if(dx< -25)targetLane=Math.max(0,targetLane-1)}else if(dy< -20)jump=.72;else if(dy>35)targetLane=1},{passive:true});
addEventListener('keydown',e=>{if(state!=='playing')return;if(e.key==='ArrowLeft'||e.key==='a')targetLane=Math.max(0,targetLane-1);if(e.key==='ArrowRight'||e.key==='d')targetLane=Math.min(2,targetLane+1);if(e.key==='ArrowUp'||e.key===' ')jump=.72});
function road(){let horizon=H*.25,base=H*.98;let center=W/2,roadW=Math.min(W*.94,540);ctx.fillStyle='#080d20';ctx.fillRect(0,0,W,H);for(let i=0;i<18;i++){let y=horizon+i*(H-horizon)/18;let k=(y-horizon)/(H-horizon);ctx.fillStyle=i%2?'#0b1630':'#0a1228';ctx.fillRect(0,y,W,(H-horizon)/18+1);ctx.strokeStyle='rgba(31,224,255,'+(0.08+k*.16)+')';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(center-roadW*k/2,y);ctx.lineTo(center+roadW*k/2,y);ctx.stroke()}
ctx.fillStyle='#101c38';ctx.beginPath();ctx.moveTo(center-roadW*.03,horizon);ctx.lineTo(center+roadW*.03,horizon);ctx.lineTo(center+roadW/2,base);ctx.lineTo(center-roadW/2,base);ctx.closePath();ctx.fill();
for(let l=1;l<=2;l++){ctx.strokeStyle='#31dfff';ctx.globalAlpha=.18;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(center+(l-1.5)*roadW*.02,horizon);ctx.lineTo(center+(l-1.5)*roadW/3,base);ctx.stroke();ctx.globalAlpha=1}
for(let s=0;s<2;s++){let x=s===0?center-roadW*.52:center+roadW*.52;ctx.strokeStyle='#ff3ec9';ctx.globalAlpha=.55;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(center+(s===0?-roadW*.03:roadW*.03),horizon);ctx.lineTo(x,base);ctx.stroke();ctx.globalAlpha=1}}
function laneX(lane,p){let roadW=Math.min(W*.94,540),center=W/2;return center+(lane-1)*roadW*.29*p}
function drawRunner(){let x=laneX(lane,1),y=H*.82-(jump>0?Math.sin((.72-jump)/.72*Math.PI)*H*.16:0);ctx.save();ctx.translate(x,y);ctx.shadowBlur=22;ctx.shadowColor='#31eaff';ctx.fillStyle=shield?'#ffe66d':'#35eaff';ctx.beginPath();ctx.ellipse(0,25,15,5,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#172b4d';ctx.fillRect(-10,-25,20,34);ctx.fillStyle='#dffcff';ctx.beginPath();ctx.arc(0,-35,10,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#35eaff';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(-7,5);ctx.lineTo(-13,20);ctx.moveTo(7,5);ctx.lineTo(13,20);ctx.stroke();ctx.restore()}
function spawnObj(){let lane=Math.floor(Math.random()*3),type=Math.random()<.64?'block':'crystal';if(Math.random()<.12)type='gap';objects.push({lane,type,p:.03,hit:false})}
function drawObj(o){let x=laneX(o.lane,o.p),y=H*.25+o.p*H*.73,size=9+o.p*31;ctx.save();if(o.type==='crystal'){ctx.translate(x,y);ctx.rotate(Math.PI/4);ctx.shadowBlur=18;ctx.shadowColor='#31eaff';ctx.fillStyle='#35eaff';ctx.fillRect(-size*.35,-size*.35,size*.7,size*.7)}else if(o.type==='gap'){ctx.fillStyle='#02040c';ctx.fillRect(x-size,y-size*.25,size*2,size*.5);ctx.strokeStyle='#ff3ec9';ctx.strokeRect(x-size,y-size*.25,size*2,size*.5)}else{ctx.shadowBlur=15;ctx.shadowColor='#ff3e91';ctx.fillStyle='#bd286e';ctx.fillRect(x-size,y-size,size*2,size*1.7);ctx.strokeStyle='#ff8cc0';ctx.strokeRect(x-size,y-size,size*2,size*1.7)}ctx.restore()}
function loop(now){if(state!=='playing')return;let dt=Math.min((now-last)/1000,.04);last=now;elapsed+=dt;score+=dt*speed*12;speed=1+elapsed*.018;spawn-=dt;if(spawn<=0){spawnObj();spawn=Math.max(.42,1.08-elapsed*.008)*(0.75+Math.random()*.5)}
lane+=(targetLane-lane)*Math.min(1,dt*13);if(jump>0)jump=Math.max(0,jump-dt);
road();let keep=[];for(let o of objects){o.p+=dt*(.42+speed*.055);if(o.p>.86&&!o.hit&&Math.abs(lane-o.lane)<.38){o.hit=true;if(o.type==='crystal'){runCoins+=1+save.boost;$('runCoins').textContent=runCoins;for(let i=0;i<5;i++)particles.push({x:laneX(o.lane,o.p),y:H*.25+o.p*H*.73,vx:(Math.random()-.5)*90,vy:-Math.random()*100,t:.5});}else if(o.type==='block'||o.type==='gap'){if(o.type==='gap'&&jump>.18){}else if(shield){shield=false;toast('SHIELD SAVED YOU')}else{end();return}}}
if(o.p<1.08)keep.push(o);drawObj(o)}objects=keep;
for(let p of particles){p.t-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;ctx.globalAlpha=Math.max(0,p.t*2);ctx.fillStyle='#35eaff';ctx.fillRect(p.x,p.y,4,4)}ctx.globalAlpha=1;particles=particles.filter(p=>p.t>0);
drawRunner();$('score').textContent=Math.floor(score)+' m';requestAnimationFrame(loop)}
// Ambient skyline and idle animation
function backdrop(){if(state==='playing')return;road();let t=performance.now()/1000;for(let i=0;i<12;i++){let x=(i/12)*W,w=W/18,h=30+(i*37%90);ctx.fillStyle='#101a35';ctx.fillRect(x,H*.25-h,w,h);ctx.fillStyle='#26cce8';for(let j=0;j<3;j++)ctx.fillRect(x+5+j*8,H*.25-h+10,3,3)}requestAnimationFrame(backdrop)}
updateHome();show('home');backdrop();
})();
