# Shadow Runner

A playable Android endless-runner prototype built with Kotlin + a local HTML5 Canvas game.

## Build
The included GitHub Actions workflow builds a debug APK on pushes to `main`.
It uses Java 17, Gradle 8.13, Android platform 35, and Build Tools 35.0.0.

## Controls
- Swipe left/right: change lanes
- Swipe up: jump over gaps
- Collect cyan crystals
- Avoid pink barriers and rooftop gaps

## Notes
This is the first playable release candidate. It is an offline game prototype and does not include ads, analytics, accounts, or in-app purchases.
