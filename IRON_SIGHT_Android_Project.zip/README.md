# IRON SIGHT — Android Prototype

A free, offline-capable Android WebView shooting-range prototype.

## Build
Open this project in Android Studio, or push it to GitHub and run **Actions → Build IRON SIGHT Android APK**. The workflow uploads `iron-sight-debug-apk`.

## Current prototype features
- Landscape Android app, offline HTML/CSS/JS assets
- Tap-to-hit target range with score and timed drill
- First-person / third-person presentation toggle
- Workshop with selectable optic, stock, grip and finish appearance
- Save loadout locally on device

## Notes
This is an early playable prototype, not a finished commercial 3D game. Weapon attachments are currently represented as customization selections and visual styling. Later versions can add more detailed 3D assets, sound, animations, additional modes, unlock progression and device graphics settings.
